//
//  GameZoneTests.swift
//  GameZoneTests
//
//  Created by Diogo Freitas on 01/11/2024.
//

import Testing
@testable import GameZone

struct GameZoneTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
