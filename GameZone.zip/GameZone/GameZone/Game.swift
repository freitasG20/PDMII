//
//  Game.swift
//  GameZone
//
//  Created by Diogo Freitas on 01/11/2024.
//

struct Game: Identifiable, Codable {
    let id: Int
    let name: String
    let rating: Double? // Torne 'rating' opcional
    let background_image: String?
}

