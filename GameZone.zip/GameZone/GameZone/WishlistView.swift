//
//  WishlistView.swift
//  GameZone
//
//  Created by Diogo Freitas on 01/11/2024.
//

import SwiftUI

struct WishlistView: View {
    var body: some View {
        Text("Wishlist")
            .font(.largeTitle)
            .padding()
    }
}
