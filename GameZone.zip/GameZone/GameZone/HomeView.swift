//
//  HomeView.swift
//  GameZone
//
//  Created by Diogo Freitas on 01/11/2024.
//

import SwiftUI

struct HomeView: View {
    @State private var games: [Game] = [] // Array que armazenará os jogos da API
    @State private var numberOfGames = 10 // Valor inicial, pode ser alterado nas settings
    
    var body: some View {
        NavigationView {
            List(games) { game in
                GameRow(game: game)
            }
            .navigationTitle("Jogos")
            .toolbar {
                Button(action: fetchGames) {
                    Image(systemName: "arrow.clockwise")
                }
            }
        }
        .onAppear {
            self.numberOfGames = UserDefaults.standard.integer(forKey: "numberOfGames")
            fetchGames()
        }
    }
    
    func fetchGames() {
        guard let url = URL(string: "https://api.rawg.io/api/games?key=7babdf689e164381bf247d2e36d79259&page_size=\(numberOfGames)") else { return }
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            if let data = data {
                let decoder = JSONDecoder()
                decoder.keyDecodingStrategy = .convertFromSnakeCase
                if let decodedResponse = try? decoder.decode(GamesResponse.self, from: data) {
                    DispatchQueue.main.async {
                        self.games = decodedResponse.results
                    }
                }
            }
        }.resume()
        
    }
    
    struct GamesResponse: Codable {
        let results: [Game]
    }
    
}
