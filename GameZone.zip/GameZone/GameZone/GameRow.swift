//
//  GameRow.swift
//  GameZone
//
//  Created by Diogo Freitas on 01/11/2024.
//

import SwiftUI

struct GameRow: View {
    let game: Game

    var body: some View {
        HStack {
            if let imageURL = game.background_image, let url = URL(string: imageURL) {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .empty:
                        Color.gray // Placeholder enquanto a imagem carrega
                            .frame(width: 50, height: 50)
                            .clipShape(RoundedRectangle(cornerRadius: 8))
                    case .success(let image):
                        image.resizable()
                             .aspectRatio(contentMode: .fill)
                             .frame(width: 50, height: 50)
                             .clipShape(RoundedRectangle(cornerRadius: 8))
                    case .failure:
                        Color.red // Placeholder caso a imagem falhe ao carregar
                            .frame(width: 50, height: 50)
                            .clipShape(RoundedRectangle(cornerRadius: 8))
                    @unknown default:
                        Color.gray
                            .frame(width: 50, height: 50)
                            .clipShape(RoundedRectangle(cornerRadius: 8))
                    }
                }
            } else {
                // Caso o URL da imagem seja nulo
                Color.gray
                    .frame(width: 50, height: 50)
                    .clipShape(RoundedRectangle(cornerRadius: 8))
            }

            Text(game.name)
            Spacer()
            if let rating = game.rating {
                Text("\(rating, specifier: "%.1f")/5")
                    .foregroundColor(.secondary)
            } else {
                Text("N/A")
                    .foregroundColor(.secondary)
            }
        }
    }
}




