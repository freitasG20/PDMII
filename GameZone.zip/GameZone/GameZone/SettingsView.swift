//
//  SettingsView.swift
//  GameZone
//
//  Created by Diogo Freitas on 01/11/2024.
//

import SwiftUI

struct SettingsView: View {
    @AppStorage("numOfGames") private var numOfGames: Int = 10
    @AppStorage("notificationTime") private var notificationTime: Date = defaultNotificationTime()
    
    var body: some View {
        Form {
            Section(header: Text("Configurações Gerais")) {
                Stepper("Número de jogos por pedido: \(numOfGames)", value: $numOfGames, in: 1...50)
            }
            
            Section(header: Text("Notificações")) {
                DatePicker("Hora preferencial para notificação", selection: $notificationTime, displayedComponents: .hourAndMinute)
                    .datePickerStyle(WheelDatePickerStyle())
            }
        }
        .navigationTitle("Definições")
    }
    
    // Define um horário padrão para a notificação (por exemplo, 8:00 AM)
    private static func defaultNotificationTime() -> Date {
        var components = DateComponents()
        components.hour = 8
        components.minute = 0
        return Calendar.current.date(from: components) ?? Date()
    }
}

