//
//  GameZoneApp.swift
//  GameZone
//
//  Created by Diogo Freitas on 01/11/2024.
//

import SwiftUI

@main
struct GameZoneApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
